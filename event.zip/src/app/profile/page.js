import Header from "./component/Header";
// import Footer from "./component/Footer";
import Aside from "./component/Aside";
import Main from "./component/Main";
import Footer from "./component/Footer";

export default function profile() {
    return (
        <div>
            
            <Header />
            <Aside />
            <Main />
            {/* <Footer /> */}


            
       {/* <!-- ======= Footer ======= --> */}
       {/* <footer id="footer" className="footer">
                <div className="copyright">
                    &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
                </div>
                <div className="credits">

                    Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                </div>
            </footer> */}
            {/* <!-- End Footer --> */}

        </div>
    )
}